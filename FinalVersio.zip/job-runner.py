import os




input_parama = [ {"db_name":"global_ent", "table_name":"item", "s3_location":"s3a://travelers-poc-buckets/warehouse/global_ent.db/item", "export_format":"parquet"},
                {"db_name":"global_ent", "table_name":"customer", "s3_location":"s3a://travelers-poc-buckets/warehouse/global_ent.db/customer", "export_format":"parquet"},
                {"db_name":"global_ent", "table_name":"supplier", "s3_location":"s3a://travelers-poc-buckets/warehouse/global_ent.db/supplier", "export_format":"parquet"},
                {"db_name":"global_ent", "table_name":"promotion", "s3_location":"s3a://travelers-poc-buckets/warehouse/global_ent.db/promotion", "export_format":"parquet"}
                ]


for ele in input_parama:
    db_name = ele["db_name"]
    tbl_name = ele["table_name"]
    target_s3_location = ele["s3_location"]
    export_format = ele["export_format"]
    print("DBName:",db_name,"\t TableName:",tbl_name,"\t Target S3 Location:",target_s3_location," \t Export Format:",export_format)
    print("Submitting Spark Job For Table:",tbl_name)
    os.system("spark-submit history-loader-pyspark.py {} {} {} {}".format(db_name,tbl_name,target_s3_location,export_format))
    print("\n \n ")
