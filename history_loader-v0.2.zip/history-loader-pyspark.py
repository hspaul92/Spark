import sys
import os
from pyspark.sql import SparkSession

spark = SparkSession.builder.master('yarn') .appName('travelers-history-loader').enableHiveSupport().getOrCreate()

spark = SparkSession.builder.getOrCreate()
sc = spark.sparkContext

hdpConf = sc._jsc.hadoopConfiguration()
user = os.getenv("USER")
hdpConf.set("hadoop.security.credential.provider.path", "jceks://hdfs/user/{}/awskeyfile.jceks".format(user))
hdpConf.set("fs.s3a.fast.upload", "true")
hdpConf.set("fs.s3a.fast.upload.buffer", "bytebuffer")
hadoopConf=sc._jsc.hadoopConfiguration()
hdpConf.set("fs.s3a.buffer.dir", "/home/hadoop,/tmp")

print("\n\n\n Cluster Configuration:",sc.getConf().getAll())



database_name= sys.argv[1]
table_name= sys.argv[2]
s3_location= sys.argv[3]
export_file_format= sys.argv[4]



readTable = spark.sql('SELECT * FROM {}.{}'.format(database_name, table_name))
record_cnt = readTable.count()
print("\n\nSource DB              :", database_name)
print("\nTable Name             :", table_name)
print("\nRecord Count           :", record_cnt)
print("\nTarget S3 Bucket       :", s3_location)
print("\nExport File Format     :", export_file_format)


try:  # If the Table Partition
    getpartitionCol = spark.sql("SHOW PARTITIONS {}.{}".format(database_name, table_name)).take(1)
    first_partitions = str(getpartitionCol[0]).replace("Row(partition=", "").strip('\'\)').split("/")
    partitionCol = [cols.split("=")[0] for cols in first_partitions]
    print("\nPartition Col         :", partitionCol)

    readTable.write.partitionBy(*partitionCol).parquet(s3_location, mode="overwrite", )

    spark.sql("INSERT INTO HISTROY_LOAD_METADATA.HISTROY_LOAD_LOG SELECT '{}',{},current_timestamp".format(table_name,record_cnt))
    print("\n\n\n")

except Exception as e:
    print("\nPartitioned Columns    : The Table Is Not Partitioned")
    readTable.write.parquet(s3_location, mode="overwrite", )
    spark.sql("INSERT INTO HISTROY_LOAD_METADATA.HISTROY_LOAD_LOG SELECT '{}',{},current_timestamp".format(table_name,record_cnt))


